"""Modeles du serveur carrefour."""
